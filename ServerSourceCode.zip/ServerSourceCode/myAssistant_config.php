<?php
//This file will be used in CP2 Assignment  by myAssistant Team

//define ('DB_CONNECTION_STRING', "mysql:host=localhost;dbname=myAssistant_db");
/*
Mysql: qdm7124576.my3w.com:3306
dbname: qdm7124576_db
username: qdm7124576
password: Teamwork.4
*/
define ('DB_CONNECTION_STRING', "mysql:host=qdm7124576.my3w.com:3306;dbname=qdm7124576_db");
define ('DB_USER', "qdm7124576");
define ('DB_PASS', "Teamwork.4");
define ('MSG_ERR_CONNECTION', "Open connection to the database first");

//the folder where user Avatar photos are stored
define ('_AVATAR_PHOTO_FOLDER_', "photos/");

//define switch parameters
define ('STR_OPERATION','operation');

//User manipulation
define ('STR_EMAIL','email');
define ('STR_PASSWORD','password');
define ('STR_NICKNAME','nickname');
define ('STR_AVATARPATH','avatarpath');
define ('STR_USER_ID','user_id');

//Note manipulation
define ('STR_NOTEID','note_id');
define ('STR_NOTETITLE','title');
define ('STR_NOTEAUTHOR','author');
define ('STR_NOTECONTENT','content');

//define error messages
define ('errSuccess', 'SUCCESS'); //no error, command is successfully executed

?>
