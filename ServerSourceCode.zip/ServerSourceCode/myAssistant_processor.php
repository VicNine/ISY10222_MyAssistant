<?php
/*
@Author: Gong
@Modify by:
@Version: 1.0
*/
//This file will be used in  Assignment  by myAssistant Team

header('Access-Control-Allow-Origin: *');

require_once('myAssistant_config.php');
require_once('myAssistant_funcTools.php');

  //empty value check
   if(empty($_REQUEST[STR_OPERATION])){
      $_REQUEST[STR_OPERATION] = null;
   }

   $request = $_REQUEST[STR_OPERATION];
   $appTools = new AppTools();

   //判断过滤器
   switch($request){
      case "login": userLoginProcessor();break;
      case "register": userRegisterProcessor();break;
      case "userUpdate": userInfoUpdate();break;
      case "readAllNotes": noteReadAll();break;
      case "createNote": noteCreate();break;
      case "readNote": noteRead();break;
      case "updateNote": noteUpdate();break;
      case "deleteNote": noteDelete();break;
      case "searchNote": noteSearch();break;
      case "userInfo": userInfoById();break;

      default: echo '\'{"judgement":"NoRequest"}\'';
   }

   //用户登陆
   function userLoginProcessor(){
      global $appTools;

      $email = $_REQUEST[STR_EMAIL];
      $password = $_REQUEST[STR_PASSWORD];

      $appTools->userLogin($email,$password);
   }

   //用户注册
   function userRegisterProcessor(){
      global $appTools;

      $user["email"] = $_REQUEST[STR_EMAIL];
      $user["password"] = $_REQUEST[STR_PASSWORD];

      $appTools->userRegister($user);
   }

   //Update user information,
   function userInfoUpdate(){
      global $appTools;

      $user["password"] = $_REQUEST[STR_PASSWORD];
      $user["nickname"] = $_REQUEST[STR_NICKNAME];
      $user["email"] = $_REQUEST[STR_EMAIL];
      $user["user_id"] = $_REQUEST[STR_USER_ID];
      $user["avatarpath"] = $_REQUEST['avatarpath'];

      $appTools->userInfoUpdate($user);
   }

   //List all info of current user
   function userInfoById(){
      global $appTools;

      $UID = $_REQUEST[STR_USER_ID];

      $appTools->userInfoById($UID);
   }

   //List all notes of current user
   function noteReadAll(){
      global $appTools;

      $UID = $_REQUEST[STR_USER_ID];

      $appTools->noteReadAll($UID);
   }

   //Read a note content from note list
   function noteRead(){
      global $appTools;

      $noteid = $_REQUEST[STR_NOTEID];

      $appTools->noteRead($noteid);
   }

   //Create a note by the user
   function noteCreate(){
      global $appTools;

      $note["title"] = $_REQUEST[STR_NOTETITLE];
      $note["author"] = $_REQUEST[STR_NOTEAUTHOR];
      $note["content"] = $_REQUEST[STR_NOTECONTENT];
      $note["UID"] = $_REQUEST[STR_USER_ID];

      $appTools->noteCreate($note);
   }

   //Update a note from the user account
   function noteUpdate(){
      global $appTools;

      $note["note_id"] = $_REQUEST[STR_NOTEID];
      $note["title"] = $_REQUEST[STR_NOTETITLE];
      $note["author"] = $_REQUEST[STR_NOTEAUTHOR];
      $note["content"] = $_REQUEST[STR_NOTECONTENT];

      $appTools->noteUpdate($note);
   }

   //Delete a note from the user account
   function noteDelete(){
      global $appTools;

      $note["note_id"] = $_REQUEST[STR_NOTEID];

      $appTools->noteDelete($note);
   }

   //Search a note by user input
   function noteSearch(){
      global $appTools;

      $note["UID"] = $_REQUEST[STR_USER_ID];
      $note["title"] = $_REQUEST[STR_NOTETITLE];

      $appTools->noteSearch($note);
   }

?>
