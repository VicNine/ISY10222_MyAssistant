<?php
/*
@Author: Gong
@Modify by:
@Version: 1.0
*/
//This file will be used in  Assignment  by myAssistant Team
  header('Access-Control-Allow-Origin: *');

	require_once('myAssistant_config.php');
	require_once('myAssistant_funcTools.php');

  //check the user id
	if(empty($_POST['user_id']))
	   echo '\'{"judgement":"NoUID"}\'';
  else{
  //get photo file name
    $userid = $_POST['user_id'];
		$photo_file = saveUserPhoto('file', _AVATAR_PHOTO_FOLDER_, 'user'.$userid, true);

		echo json_encode($photo_file);
  }

  function saveUserPhoto($uploader, $target_dir, $filename, $override) {
    try {
      // Undefined | Multiple Files | $_FILES Corruption Attack
      // If this request falls under any of them, treat it invalid.
      if (!isset($_FILES[$uploader]['error']) || is_array($_FILES[$uploader]['error'])) {
        throw new RuntimeException('Invalid parameters.');
      }
      // Check $_FILES[$uploader]['error'] value.
      switch ($_FILES[$uploader]['error']) {
        case UPLOAD_ERR_OK:
          break;
        case UPLOAD_ERR_NO_FILE:
          throw new RuntimeException('No file sent.');
        case UPLOAD_ERR_INI_SIZE:
        case UPLOAD_ERR_FORM_SIZE:
          throw new RuntimeException('Exceeded filesize limit.');
        default:
          throw new RuntimeException('Unknown errors.');
      }
      // You should also check filesize here ( > 1 MegaBytes).
      define ("MAX_FILE_SIZE", 100000000);
      if ($_FILES[$uploader]['size'] > MAX_FILE_SIZE) {
        throw new RuntimeException('Exceeded filesize limit.');
      }
      // DO NOT TRUST $_FILES[$uploader]['mime'] VALUE !!
      // Check MIME Type by yourself.
      $finfo = new finfo(FILEINFO_MIME_TYPE);
      if (false === $ext = array_search(
        $finfo->file($_FILES[$uploader]['tmp_name']),
        array(
          'jpg' => 'image/jpeg',
          'png' => 'image/png',
          'gif' => 'image/gif',
        ),
        true
      )) {
        throw new RuntimeException('Invalid file format.');
      }
      // Check if file already exists
      $target_file = $target_dir . $filename . "." . $ext; //get the fullpath to the file
      if ((!$override) && (file_exists($target_file))) {
        throw new RuntimeException('File already exists');
      }
      // You should name it uniquely.
      // DO NOT USE $_FILES[$uploader]['name'] WITHOUT ANY VALIDATION !!
      // On this example, obtain safe unique name from its binary data.
      if (!move_uploaded_file($_FILES[$uploader]['tmp_name'], $target_file)) {
        throw new RuntimeException('Failed to move uploaded file.');
      }

      //return null for success
      return $filename . "." . $ext;

    } catch (RuntimeException $e) {
      //we don't throw exception, simply return the default file name
      //return $e->getMessage();
      return 'default.jpg';
    }
  }
?>
