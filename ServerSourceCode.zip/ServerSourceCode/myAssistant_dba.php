<?php
/*dbAdapter: this module acts as the database abstraction layer for the application
@Author: Gong
@Modify by:
@Version: 1.0
//This file will be used in  Assignment  by myAssistant Team
/*Connection paramaters
*/
require_once('myAssistant_config.php');

/* DBAdpater class performs all required CRUD functions for the application
*/
class DBAdaper {
	/*local variables
	*/
	private $dbConnectionString;
	private $dbUser;
	private $dbPassword;
	private $dbConn; //holds connection object
	private $dbError; //holds last error message

	/* The class constructor
	*/
	public function __construct($dbConnectionString, $dbUser, $dbPassword) {
		$this->dbConnectionString = $dbConnectionString;
		$this->dbUser = $dbUser;
		$this->dbPassword = $dbPassword;
	}

	/*Opens connection to the database
	*/
	public function dbOpen() {
		try {
			$this->dbConn = new PDO($this->dbConnectionString, $this->dbUser, $this->dbPassword);
			// set the PDO error mode to exception
			$this->dbConn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			$this->dbError = null;
		}
		catch(PDOException $e) {
			$this->dbError = $e->getMessage();
			$this->dbConn = null;
		}
	}
	/*Closes connection to the database
	*/
	public function dbClose() {
		//in PDO assigning null to the connection object closes the connection
		$this->dbConn = null;
	}
	/*Return last database error
	*/
	public function lastError() {
		return $this->dbError;
	}


	/*-------------------------------------------------------------------------------------------
                              DATABASE MANIPULATION FUNCTIONS
	-------------------------------------------------------------------------------------------*/

  /*fetch the user data by their username
	@return: user data.
	*/
	public function userLogin($email){
		$result = null;
		$this->dbError = null; //reset the error message before any execution
		if ($this->dbConn != null) {
			//Try and insert the member, if there is a DB exception return
			//the error message to the caller.
			try {

				//Make a prepared query so that we can use data binding and avoid SQL injections.
				//(modify suit the A2 member table)
				$sql = "SELECT `user_id`,`nickname`,`email`,`avatarpath`,`password` FROM
				`user` WHERE email='$email'";

				$smt = $this->dbConn->prepare($sql);
				//Execute the query
				$smt->execute();
				$result = $smt->fetchAll(PDO::FETCH_ASSOC);

				//use PDO::FETCH_BOTH to have both column name and column index
				//$result = $sql->fetchAll(PDO::FETCH_BOTH);
			}catch (PDOException $e) {
				//Return the error message to the caller
				$this->dbError = $e->getMessage();
				$result = null;
			}
		} else {
			$this->dbError = MSG_ERR_CONNECTION;
		}

		return $result;
	}

  /*fetch the user data by their id
	@return: user data.
	*/
	public function userSelectById($userId){
		$result = null;
		$this->dbError = null; //reset the error message before any execution
		if ($this->dbConn != null) {
			//Try and insert the member, if there is a DB exception return
			//the error message to the caller.
			try {

				//Make a prepared query so that we can use data binding and avoid SQL injections.
				//(modify suit the A2 member table)
				$sql = "SELECT `user_id`,`nickname`,`email`,`avatarpath`,`password` FROM
				`user` WHERE user_id='$userId'";

				$smt = $this->dbConn->prepare($sql);
				//Execute the query
				$smt->execute();
				$result = $smt->fetchAll(PDO::FETCH_ASSOC);
				//use PDO::FETCH_BOTH to have both column name and column index
				//$result = $sql->fetchAll(PDO::FETCH_BOTH);
			}catch (PDOException $e) {
				//Return the error message to the caller
				$this->dbError = $e->getMessage();
				$result = null;
			}
		} else {
			$this->dbError = MSG_ERR_CONNECTION;
		}

		return $result;
	}

	/*Add the new user into the user table
	@return: a last insert user id.
	*/
	public function userJoin($user) {
		$result = null;
		$this->dbError = null; //reset the error message before any execution
		if ($this->dbConn != null) {
		    // used server date this time not client
		    $joindate = date("Y-m-d H:i:s");
			//Try and insert the member, if there is a DB exception return
			//the error message to the caller.
			try {
				//Make a prepared query so that we can use data binding and avoid SQL injections.


				$smt = $this->dbConn->prepare('INSERT INTO `user`( `email`,
				       `password`, `join_date`)
				       VALUES (:email, :password,:join_date);');

				//Bind the data from the form to the query variables.
				//Doing it this way means PDO sanitises the input which prevents SQL injection.
				$smt->bindParam(':email', $user['email'], PDO::PARAM_STR);
				$smt->bindParam(':password', $user['password'], PDO::PARAM_STR);
				$smt->bindParam(':join_date', $joindate, PDO::PARAM_STR);

				//Execute the query and thus insert the member
				$smt->execute();
				$result = $this->dbConn->lastInsertId();

			}catch (PDOException $e) {
				//Return the error message to the caller
				$this->dbError = $e->getMessage();
				$result = null;
			}
		} else {
			$this->dbError = MSG_ERR_CONNECTION;
		}
		return $result;
	}

  /*update the user into the user table
	@return:true.
	*/
	public function userUpdate($user) {
		$result = null;
		$this->dbError = null; //reset the error message before any execution
		if ($this->dbConn != null) {
			//Try and insert the member, if there is a DB exception return
			//the error message to the caller.
			try {
				//Make a prepared query so that we can use data binding and avoid SQL injections.

				$smt = $this->dbConn->prepare('UPDATE user SET
                                                            nickname = :nickname,
                                                            password = :password,
                                                            email = :email,
                                                            avatarpath = :avatarpath
                                                        WHERE user_id = :user_id;');

				//Bind the data from the form to the query variables.
				//Doing it this way means PDO sanitises the input which prevents SQL injection.
				$smt->bindParam(':nickname', $user['nickname'], PDO::PARAM_STR);
				$smt->bindParam(':password', $user['password'], PDO::PARAM_STR);
				$smt->bindParam(':email', $user['email'], PDO::PARAM_STR);
				$smt->bindParam(':avatarpath', $user['avatarpath'], PDO::PARAM_STR);
				$smt->bindParam(':user_id', $user['user_id'], PDO::PARAM_INT);

				//Execute the query and thus insert the member
				$result = $smt->execute();

				return $result;

			}catch (PDOException $e) {
				//Return the error message to the caller
				$this->dbError = $e->getMessage();
				$result = null;
			}
		} else {
			$this->dbError = MSG_ERR_CONNECTION;
		}

		return $result;
	}

  /*delete the user from the user table  by member id.
	*/
	public function userDeleteById($userId) {
		$result = null;
		$this->dbError = null; //reset the error message before any execution
		if ($this->dbConn != null) {
			try {

				//sql to delete a member based on given params
				$sql = "DELETE FROM user WHERE user_id=$userId";

				$result = $this->dbConn->exec($sql);
			} catch (PDOException $e) {
				//Return the error message to the caller
				$this->dbError = $e->getMessage();
				$result = null;
			}
		} else {
			$this->dbError = MSG_ERR_CONNECTION;
		}

		return $result;
	}

	/*Select all existing notes from the note table
	@return: an array of matched movies
	*/
	public function noteSelectAll($UID) {
		$result = null;
		$this->dbError = null; //reset the error message before any execution
		if ($this->dbConn != null) {
			try {
				//Make a prepared query so that we can use data binding and avoid SQL injections.
				//(modify suit the A2 member table)
				$smt = $this->dbConn->prepare(
					'SELECT `note_id` ,`UID`, `title`, `author` ,`pages` ,`content`, `create_date` FROM `note` WHERE UID='.$UID);
				//Execute the query
				$smt->execute();
				$result = $smt->fetchAll(PDO::FETCH_ASSOC);
				//use PDO::FETCH_BOTH to have both column name and column index
				//$result = $sql->fetchAll(PDO::FETCH_BOTH);
			}catch (PDOException $e) {
				//Return the error message to the caller
				$this->dbError = $e->getMessage();
				$result = null;
			}
		} else {
			$this->dbError = MSG_ERR_CONNECTION;
		}
		return $result;
	}

	/*fetch the note data by their id
	@return: note data.
	*/
	public function noteSelectById($noteId){
		$result = null;
		$this->dbError = null; //reset the error message before any execution
		if ($this->dbConn != null) {
			//Try and insert the member, if there is a DB exception return
			//the error message to the caller.
			try {

				//Make a prepared query so that we can use data binding and avoid SQL injections.
				//(modify suit the A2 member table)
				$sql = "SELECT `note_id`,`UID`,`title`,`author`,`content`,`create_date`,`pages` FROM
				`note` WHERE note_id='$noteId'";

				$smt = $this->dbConn->prepare($sql);
				//Execute the query
				$smt->execute();
				$result = $smt->fetchAll(PDO::FETCH_ASSOC);

				//use PDO::FETCH_BOTH to have both column name and column index
				//$result = $sql->fetchAll(PDO::FETCH_BOTH);
			}catch (PDOException $e) {
				//Return the error message to the caller
				$this->dbError = $e->getMessage();
				$result = null;
			}
		} else {
			$this->dbError = MSG_ERR_CONNECTION;
		}

		return $result;
	}

	/*Create a new note into the note table
	@return: a last insert note id.
	*/
	public function noteCreate($note) {
		$result = null;
		$this->dbError = null; //reset the error message before any execution
		if ($this->dbConn != null) {
		    // used server date this time not client
		    $createDate = date("Y-m-d");
			//Try and insert the member, if there is a DB exception return
			//the error message to the caller.
			try {
				//Make a prepared query so that we can use data binding and avoid SQL injections.

				$smt = $this->dbConn->prepare('INSERT INTO `note`( `UID`, `title`, `author`,
				  `pages`, `content`, `create_date`)
				   VALUES (:UID, :title, :author, :pages, :content, :create_date);');

				//Bind the data from the form to the query variables.
				//Doing it this way means PDO sanitises the input which prevents SQL injection.
				$smt->bindParam(':UID', $note['UID'], PDO::PARAM_INT);
				$smt->bindParam(':title', $note['title'], PDO::PARAM_STR);
				$smt->bindParam(':author', $note['author'], PDO::PARAM_STR);
				$smt->bindParam(':pages', $note['pages'], PDO::PARAM_INT);
				$smt->bindParam(':content', $note['content'], PDO::PARAM_STR);
				$smt->bindParam(':create_date', $createDate, PDO::PARAM_STR);

				//Execute the query and thus insert the member
				$smt->execute();
				$result = $this->dbConn->lastInsertId();

			}catch (PDOException $e) {
				//Return the error message to the caller
				$this->dbError = $e->getMessage();
				$result = null;
			}
		} else {
			$this->dbError = MSG_ERR_CONNECTION;
		}

		return $result;
	}

  /*update the note into the note table
	@return: a last insert note id.
	*/
	public function noteUpdate($note) {
		$result = null;
		$this->dbError = null; //reset the error message before any execution
		if ($this->dbConn != null) {
			//Try and insert the member, if there is a DB exception return
			//the error message to the caller.
			try {
				//Make a prepared query so that we can use data binding and avoid SQL injections.

				$smt = $this->dbConn->prepare('UPDATE note SET
                                                            title = :title,
                                                            author = :author,
                                                            content = :content,
																														pages = :pages
                                                        WHERE note_id = :note_id;');

				//Bind the data from the form to the query variables.
				//Doing it this way means PDO sanitises the input which prevents SQL injection.
				$smt->bindParam(':title', $note['title'], PDO::PARAM_STR);
				$smt->bindParam(':author', $note['author'], PDO::PARAM_STR);
				$smt->bindParam(':content', $note['content'], PDO::PARAM_STR);

				$smt->bindParam(':pages', $note['pages'], PDO::PARAM_INT);
				$smt->bindParam(':note_id', $note['note_id'], PDO::PARAM_INT);

				//Execute the query and thus insert the note
				$smt->execute();
				$result = $this->dbConn->lastInsertId();

			}catch (PDOException $e) {
				//Return the error message to the caller
				$this->dbError = $e->getMessage();
				$result = null;
			}
		} else {
			$this->dbError = MSG_ERR_CONNECTION;
		}

		return $result;
	}

  /*delete the note from the note table  by member id.
	*/
	public function noteDeleteById($noteId) {
		$result = null;
		$this->dbError = null; //reset the error message before any execution
		if ($this->dbConn != null) {
			try {

				//sql to delete a member based on given params
				$sql = "DELETE FROM note WHERE note_id=$noteId";

				$result = $this->dbConn->exec($sql);
			} catch (PDOException $e) {
				//Return the error message to the caller
				$this->dbError = $e->getMessage();
				$result = null;
			}
		} else {
			$this->dbError = MSG_ERR_CONNECTION;
		}

		return $result;
	}

	/*Filter existing title from the note table
	@param $keyword: a keyword to match the make name
	@return: an array of matched makes
	*/
	public function noteFilter($UID,$keyword) {
		$result = null;
		$this->dbError = null; //reset the error message before any execution
		if ($this->dbConn != null) {
			try {
				//Make a prepared query so that we can use data binding and avoid SQL injections.
				//(modify suit the A2 member table)
				$sql = "SELECT * FROM note WHERE UID=$UID and title LIKE '$keyword%'";
				//SELECT * FROM note WHERE UID=1 and title LIKE 'M%';
				$smt = $this->dbConn->prepare($sql);
				//Execute the query
				$smt->execute();
				$result = $smt->fetchAll(PDO::FETCH_ASSOC);
				//use PDO::FETCH_BOTH to have both column name and column index
				//$result = $sql->fetchAll(PDO::FETCH_BOTH);
			}catch (PDOException $e) {
				//Return the error message to the caller
				$this->dbError = $e->getMessage();
				$result = null;
			}
		} else {
			$this->dbError = MSG_ERR_CONNECTION;
		}

		return $result;
	}

}//this is end of the DBA helper class

/*----------------------------------------------------------------------------------------------
                                         TEST FUNCTIONS
 ----------------------------------------------------------------------------------------------*/

/*Tests database functions
*/

function testDBA()
{
	$dbAdapter = new DBAdaper(DB_CONNECTION_STRING, DB_USER, DB_PASS);
	$dbAdapter->dbOpen();

  $result = $dbAdapter->noteSelectAll(1);

	if ($result != null)
        echo $result;
  else
        echo $dbAdapter->lastError();

	$dbAdapter->dbClose();
}

//execute the test
//testDBA();
?>
