<?php
/*dbAdapter: this module acts as the function for the application

@Author: Gong
@Modify by:
@Version: 1.0

//This file will be used in  Assignment  by myAssistant Team

/* AppTools class performs all required  functions for the application
*/

require_once('myAssistant_config.php');
require_once('myAssistant_funcTools.php');
require_once('myAssistant_dba.php');

class AppTools {

	/*-------------------------------------------------------------------------------------------
                              USERINFO MANIPULATION FUNCTIONS
	-------------------------------------------------------------------------------------------*/

	/*User login process
	@judgement: passwordNotCorrect, noRegister or userInfo
	*/
	public function userLogin($email,$password) {
	   $res = $this->dbaUserLogin($email);

	   //建立错误反馈信息:1.用户没有注册. 2.密码不正确
	   if(empty($res)){
	      echo '{"judgement":"noRegister"}';die();
	   }

	   if($password != $res[0]['password']){
	      echo '{"judgement":"passwordNotCorrect"}';die();
	   }
	  //如果全部正确,返回用户数据. 需要在客户端建立cookie会话
	   else{
	      $returnValue = '{"judgement": "userInfo","user_id":"'.$res[0]['user_id'].'"}';
	      echo $returnValue;
	   }
	}

	/*User register process
	@judgement: alreadyResigter, emptyEmail, emptyPassword or userInfo
	*/
	public function userRegister($user) {

	   if(empty($user["email"])){
	      echo '{"judgement": "emptyEmail"}';die();
	   }
	   if(empty($user["password"])){
	      echo '{"judgement": "emptyPassword"}';die();
	   }

	   $resId = $this->dbaUserRegister($user);

	   if(empty($resId)){
	      echo '{"judgement": "alreadyResigter"}';die();
	   }

      //注册成功后,根据ID 提取
      $res = $this->dbaUserSelectById($resId);
			$returnValue = '{"judgement": "userInfo","user_id":"'.$res[0]['user_id'].'"}';
			echo $returnValue;
	}

	/*User info Update process
	@judgement:   userInfo
	*/
public function userInfoById($UID) {
		//根据ID 提取
		$res = $this->dbaUserSelectById($UID);
		$returnValue = '{"judgement": "userInfo",
				 "nickname":"'.$res[0]['nickname'].'",
				 "user_id":"'.$res[0]['user_id'].'",
				 "email":"'.$res[0]['email'].'",
				 "avatarpath":"'.$res[0]['avatarpath'].'",
				 "password":"'.$res[0]['password'].'"}
			';
	 //用户信息
	 echo $returnValue;

}
	/*User info Update process
	@judgement:   userInfo
	*/
	public function userInfoUpdate($user) {

	   if(empty($user["email"])){
	      echo '{"judgement": "emptyEmail"}';die();
	   }
	   if(empty($user["password"])){
	      echo '{"judgement": "emptyPassword"}';die();
	   }
	   if(empty($user["nickname"])){
	      echo '{"judgement": "emptyNickname"}';die();
	   }

		  $temp = json_decode($user['avatarpath']);

      $user['avatarpath'] = "photos/".$temp;
      $this->dbaUserUpdate($user);

      //注册成功后,根据ID 提取
      $res = $this->dbaUserSelectById($user["user_id"]);
      $returnValue = '{"judgement": "userInfo",
	         "nickname":"'.$res[0]['nickname'].'",
	         "user_id":"'.$res[0]['user_id'].'",
	         "email":"'.$res[0]['email'].'",
	         "avatarpath":"'.$res[0]['avatarpath'].'",
	         "password":"'.$res[0]['password'].'"}';
		//更新用户信息
		 echo $returnValue;

	}




	/*-------------------------------------------------------------------------------------------
                              NoteInfo MANIPULATION FUNCTIONS
	-------------------------------------------------------------------------------------------*/


	/*Note Create process
	@judgement:  noteContent
	*/
	public function noteCreate($note) {

      //note pages
      $note["pages"] = ceil(strlen($note["content"]) /50);

      $noteId = $this->dbaNoteCreate($note);
      $returnValue = '{"judgement": "noteContent",
	         "note_id":"'.$noteId.'"
	         }';
	   echo $returnValue;
	}


	/*Note Read All process
	@judgement: noteEmpty, noteContent
	*/
	public function noteReadAll($UID) {
      $res = $this->dbaNoteReadAll($UID);
			if(empty($res)){
 	      echo '{"judgement":"noteEmpty"}';die();
 	   }
      $returnValue = '{"judgement": "noteContent","notes":'.json_encode($res).'}';
	   echo $returnValue;
	}


	/*Note Read process
	@judgement: noteContent
	*/
	public function noteRead($noteid) {
		$res = $this->dbaNoteSelectById($noteid);

		$returnValue = '{"judgement": "noteContent",
				 "title":"'.$res[0]['title'].'",
				 "author":"'.$res[0]['author'].'",
				 "content":"'.$res[0]['content'].'"
				 }';
	 echo $returnValue;
	}

	/*Note Update process
	@judgement:,updateSuccessfull
	*/
	public function noteUpdate($note) {
		//note pages
		$note["pages"] = ceil(strlen($note["content"]) /50);

		$noteId = $this->dbaNoteUpdate($note);

		$returnValue = '{"judgement": "updateSuccessfull"}';
	 echo $returnValue;
	}

	/*Note Delete process
	@judgement:deleteSuccefully
	*/
	public function noteDelete($note) {
		$res = $this->dbaNoteDelete($note["note_id"]);
		echo '{"judgement": "deleteSuccefull"}';
	}

	/*Note Search process
	@judgement: all titles matched with keywords
	*/
	public function noteSearch($keyword) {

      $res = $this->dbaNoteSearch($keyword);
			if(empty($res)){
				return '{"judgement": "noteEmpty"}';
			}
			$returnValue = '{"judgement": "noteContent","notes":'.json_encode($res).'}';

	   echo $returnValue;
	}


   /*-------------------------------------------------------------------------------------------
                            DATABASE MANIPULATION  FUNCTIONS
	-------------------------------------------------------------------------------------------*/
	/*note Search database operating
	@return note array
	*/
	private function dbaNoteSearch($note){
	   $dbaHelper = new DBAdaper(DB_CONNECTION_STRING, DB_USER, DB_PASS);
	   $dbaHelper->dbOpen();

	   $res = $dbaHelper->noteFilter($note['UID'],$note['title']);

	   $dbaHelper->dbClose();

	   return $res;
	}

	/*note Update database operating
	@return empty
	*/
	private function dbaNoteDelete($noteId){
	   $dbaHelper = new DBAdaper(DB_CONNECTION_STRING, DB_USER, DB_PASS);
	   $dbaHelper->dbOpen();

	   $res = $dbaHelper->noteDeleteById($noteId);

	   $dbaHelper->dbClose();

	   return $res;
	}

	/*note Update database operating
	@return note Id
	*/

	private function dbaNoteUpdate($note){
	   $dbaHelper = new DBAdaper(DB_CONNECTION_STRING, DB_USER, DB_PASS);
	   $dbaHelper->dbOpen();

	   $res = $dbaHelper->noteUpdate($note);

	   $dbaHelper->dbClose();

	   return $res;
	}

	/*note Create database operating
	@return note Id
	*/
	private function dbaNoteCreate($note){
	   $dbaHelper = new DBAdaper(DB_CONNECTION_STRING, DB_USER, DB_PASS);
	   $dbaHelper->dbOpen();

	   $res = $dbaHelper->noteCreate($note);

	   $dbaHelper->dbClose();

	   return $res;
	}

	/*note Create database operating
	@return note Id
	*/
	private function dbaNoteSelectById($noteId){
	   $dbaHelper = new DBAdaper(DB_CONNECTION_STRING, DB_USER, DB_PASS);
	   $dbaHelper->dbOpen();

	   $res = $dbaHelper->noteSelectById($noteId);

	   $dbaHelper->dbClose();

	   return $res;
	}

  /*note read all database operating
	@return note array
	*/
	private function dbaNoteReadAll($UID){
	   $dbaHelper = new DBAdaper(DB_CONNECTION_STRING, DB_USER, DB_PASS);
	   $dbaHelper->dbOpen();

	   $res = $dbaHelper->noteSelectAll($UID);

	   $dbaHelper->dbClose();

	   return $res;
	}

	/*User login database operating
	@return user array
	*/
	private function dbaUserLogin($email){
	   $dbaHelper = new DBAdaper(DB_CONNECTION_STRING, DB_USER, DB_PASS);
	   $dbaHelper->dbOpen();

	   $res = $dbaHelper->userLogin($email);

	   $dbaHelper->dbClose();

	   return $res;
	}

	/*User register database operating
	@return last ID
	*/
	private function dbaUserRegister($user){
	   $dbaHelper = new DBAdaper(DB_CONNECTION_STRING, DB_USER, DB_PASS);
	   $dbaHelper->dbOpen();

	   $res = $dbaHelper->userJoin($user);

	   $dbaHelper->dbClose();

	   return $res;
	}

	/*User select id database operating
	@return user array
	*/
	private function dbaUserSelectById($userId){
	   $dbaHelper = new DBAdaper(DB_CONNECTION_STRING, DB_USER, DB_PASS);
	   $dbaHelper->dbOpen();

	   $res = $dbaHelper->userSelectById($userId);

	   $dbaHelper->dbClose();

	   return $res;
	}

	/*User InfoUpdate database operating
	@return user info
	*/
	private function dbaUserUpdate($user){
	   $dbaHelper = new DBAdaper(DB_CONNECTION_STRING, DB_USER, DB_PASS);
	   $dbaHelper->dbOpen();

	   $res = $dbaHelper->userUpdate($user);

	   $dbaHelper->dbClose();

	   return $res;
	}

}//This is end of AppTools Class

?>
