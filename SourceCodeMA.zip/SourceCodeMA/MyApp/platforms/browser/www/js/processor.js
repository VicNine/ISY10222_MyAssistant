//This file will be used in  Assignment  by myAssistant Team


//targetServer = "http://localhost/myAssistant_processor.php";
//targetDomain = "http://localhost/";
targetDomain = "http://blog.2true.cn/myAssistant/";
targetServer = "http://blog.2true.cn/myAssistant/myAssistant_processor.php";

/*-------------------------------------------------------------------------------------------
                            NOTES MANIPULATION FUNCTIONS
-------------------------------------------------------------------------------------------*/

//笔记验证
function noteValidate(title,author,content){

  var Expr = [/^[\s\S]*.*[^\s][\s\S]*$/]

  if (!Expr[0].test(title)) {
      $("#newnote_topic").focus();
      $("#newnote_topic").select();
      $("#newnote_topic").css("border-color","red");
      alert("please enter a title");
      return false;
  }

  if (!Expr[0].test(author)) {
    $("#newNote_anthor").focus();
    $("#newNote_anthor").select();
    $("#newNote_anthor").css("border-color","red");
    alert("please enter an author");
    return false;
  }

  if (!Expr[0].test(content)) {
    $("#newNote_content").focus();
    $("#newNote_content").select();
    $("#newNote_content").css("border-color","red");
    alert("write something please");
    return false;
  }
  else{
    return true;
  }

}


//上传新笔记
function saveNewnote(title,author,content){


  if(!noteValidate(title,author,content)){
    return false;
  };

  $.ajax({
    type: 'post',
    url: targetServer,
    crossDomain: true,
    dataType: 'html',
    data: 'operation=createNote'+'&title='+title+'&author='+author+'&content='+content+'&user_id='+ $.cookie('user_id'),

    success: function(data) {
     var obj = JSON.parse(data);
      if(obj.judgement === "noteContent"){
       window.location.replace("readAllnotes.html");
     }else{
       alert("Store the note failure");
       window.location.replace("readAllnotes.html");
     }
    },
      error:function(e) {
        console.log(e);
      }
    })
}


//阅读所有笔记

function readAllnotes(){

  $.ajax({
      type: 'post',
      url: targetServer,
      crossDomain: true,
      dataType: 'html',
      data: 'operation=readAllNotes'+'&user_id='+$.cookie('user_id'),
      success: function(data) {
        var obj = JSON.parse(data);
        if(obj.judgement === "noteEmpty"){
          $(".noteDiv").html("<a href='newNote.html'><div class='textArea'><br><h7 style='color:gray;'>Create</h7><hr><h3><img src='img/plus.png' width='75px'/> </h3><hr><h7 style='color:gray;'>New Note</h7>");
        }
        if(obj.judgement === "noteContent"){
          var temp="";
          objnote = obj.notes;
          for(i=0; i<objnote.length;i++){
            temp += "<a href='#'><div class='textArea' onclick=aNote("+objnote[i].note_id+")><br><h7 style='color:gray;'>"+
              objnote[i].create_date+"</h7><hr><h4>"+objnote[i].title+"</h4><br><hr><h7 style='color:gray;'>"+
              objnote[i].pages+" pages</h7></div></a> "
          }
          $(".noteDiv").html(temp);
        }
      },
      error: function(e) {
       console.log(e);
      }

    });
}

// Read a note
function readAnote(){

  $.ajax({
    type: 'post',
    url: targetServer,
    crossDomain: true,
    dataType: 'html',
    data: 'operation=readNote'+'&note_id='+ $.cookie('note_id'),
    success: function(data) {
      var obj = JSON.parse(data);
      if (obj.judgement === 'noteContent') {
        $("#newnote_topic").html(obj.title);
        $("#newnote_author").html(obj.author);
        $("#newnote_content").html(obj.content);
      }
    },

    error: function(e){
      console.log(e);
    }

  });
}

//修改选中笔记
function modifyNote(title,author,content){

  if(!noteValidate(title,author,content)){
    return false;
  }
  $.ajax({
    type: 'post',
    url: targetServer,
    crossDomain: true,
    dataType: 'html',
    data: 'operation=updateNote'+'&title='+title+'&author='+author+'&content='+content+'&note_id='+$.cookie('note_id'),
    success: function(data) {
      var obj = JSON.parse(data);
      if (obj.judgement === 'updateSuccessfull') {
        window.location.replace("readAllnotes.html");
      }
    },
    error: function(e){
      console.log(e);
    }

  });

}

//delete笔记
function deleteNote(){

  $.ajax({
    type: 'post',
    url: targetServer,
    crossDomain: true,
    dataType: 'html',
    data: 'operation=deleteNote'+'&note_id='+$.cookie('note_id'),
    success: function(data) {

      var obj = JSON.parse(data);

      if (obj.judgement === 'deleteSuccefull') {
        window.location.replace("readAllnotes.html");
      }
    },

    error: function(e){
      console.log(e);
    }

  })

}



//search note by keyword
function searchNote(){

    $.ajax({
      type: 'post',
      url: targetServer,
      crossDomain: true,
      dataType: 'html',
      data: 'operation=searchNote'+'&title=' + $("#searchKeyword").val()+'&user_id=' + $.cookie('user_id'),
      success: function(data) {
        var obj = JSON.parse(data);
        if(obj.judgement === "noteEmpty"){
          readAllnotes();
        }
        else if(obj.judgement === "noteContent"){
          var temp="";
          objnote = obj.notes;
          for(i=0; i<objnote.length;i++){
            temp += "<a href='#'><div class='textArea' onclick=aNote("+objnote[i].note_id+")><br><h7 style='color:gray;'>"+
              objnote[i].create_date+"</h7><hr><h4>"+objnote[i].title+"</h4><br><hr><h7 style='color:gray;'>"+
              objnote[i].pages+" pages</h7></div></a> "
          }
          $(".noteDiv").html(temp);
        }
      },

      error: function(e){
        console.log(e);

      }

    })
}



/*-------------------------------------------------------------------------------------------
                            USERINFO MANIPULATION FUNCTIONS
-------------------------------------------------------------------------------------------*/


function loginPage(email,passwd){

  $.ajax({
      type: 'post',
      url: targetServer,
      crossDomain: true,
      dataType: 'html',
      data: 'operation=login'+'&email='+email+'&password='+passwd,
      success: function(data) {
        var obj = JSON.parse(data);
        if(obj.judgement === "noRegister"){
          $("#btnRegister").css("border-color","red");
          $("#loginNotice").html("This email is not registered.");
          $("#loginNotice").css("color","red");
        }
        if(obj.judgement === "passwordNotCorrect"){
          $("#passwd").focus();
          $("#passwd").select();
          $("#passwd").css("border-color","red");
          $("#loginNotice").html("The password is incorrected.");
          $("#loginNotice").css("color","red");
        }
        if(obj.judgement === "userInfo"){
          $.cookie('user_id', obj.user_id);
          window.location.replace("readAllnotes.html");
        }
      },
      error: function(e) {
       console.log(e);
      }

    });
}



function registerPage(email,passwd,repasswd){

  if(!registerValidate(email,passwd,repasswd)){
    return false;
  };

  $.ajax({
      type: 'post',
      url: targetServer,
      crossDomain: true,
      dataType: 'html',
      data: 'operation=register'+'&email='+email+'&password='+passwd,
      success: function(data) {
        var obj = JSON.parse(data);
        if(obj.judgement === "alreadyResigter"){
          $("#loginNotice").html("This email is registered already, please login.");
          $("#loginNotice").css("color","red");
          $("#btnLogin").css("border-color","red");
        }
        if(obj.judgement === "userInfo"){

          $.cookie('user_id', obj.user_id);
          window.location.replace("readAllnotes.html");
        }
      },
      error: function(e) {
       console.log(e);
      }

    });
}

function registerValidate(email,passwd,repasswd){

  var Expr = [/^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/, /^[\s\S]*.*[^\s][\s\S]*$/];

  if (!Expr[0].test(email)) {
      $("#email").focus();
      $("#email").select();
      $("#email").css("border-color","red");
      $("#loginNotice").html("Please enter valid email.");
      $("#loginNotice").css("color","red");
      return false;
  }

  if (!Expr[1].test(passwd)) {
    $("#password").focus();
    $("#password").select();
    $("#password").css("border-color","red");
    $("#loginNotice").html("Password can not empty.");
    $("#loginNotice").css("color","red");
    return false;
  }
  if (passwd != repasswd){
    $("#repassword").focus();
    $("#repassword").select();
    $("#repassword").css("border-color","red");
    $("#loginNotice").html("The password are not same.");
    $("#loginNotice").css("color","red");
    return false;
  }else{
    return true;
  }

}

function settingPage(){

  $.ajax({
      type: 'post',
      url: targetServer,
      crossDomain: true,
      dataType: 'html',
      data: 'operation=userInfo'+'&user_id='+$.cookie('user_id'),
      success: function(data) {
        var obj = JSON.parse(data);
        if(obj.judgement === "userInfo"){
            avatarpath = targetDomain+obj.avatarpath;
            $("#avatar").attr("src",avatarpath);
            $("#nickname").val(obj.nickname);
            $("#email").val(obj.email);
        }
      },
      error: function(e) {
       console.log(e);
      }

    });
}



function updateUserInfo(nickname,email,oldpasswd,passwd,repasswd){

  if(!registerValidate(email,passwd,repasswd)){
    return false;
  }
  $.ajax({
      type: 'post',
      url: targetServer,
      crossDomain: true,
      dataType: 'html',
      data: 'operation=userUpdate'+'&user_id='+$.cookie('user_id')+'&email='+email+'&password='+passwd+'&nickname='+nickname+"&avatarpath="+$.cookie('avatarpath'),
      success: function(data) {
        var obj = JSON.parse(data);
        if(obj.judgement === "emptyNickname"){
          $("#nickname").focus();
          $("#nickname").select();
          $("#nickname").css("border-color","red");
          $("#loginNotice").html("Please input nickname.");
          $("#loginNotice").css("color","red");

        }
        if(obj.judgement === "userInfo"){
          var avatarpath = targetDomain+obj.avatarpath;
          $("#avatar").attr("src",avatarpath);
          $("#nickname").val(obj.nickname);
          $("#email").val(obj.email);
          $("#loginNotice").html("Update successfully.");
          $("#loginNotice").css("color","green");
          $("#changeUserInfo").html("Back to note centre");
          $("#changeUserInfo").attr("href", "readAllnotes.html");

        }
      },
      error: function(e) {
       console.log(e);
      }

    });
}

 function uploadPhoto() {
    var file_data = $('#file').prop('files')[0];
    var form_data = new FormData();
    form_data.append('file', file_data);
    form_data.append('user_id', $.cookie('user_id'));
    $.ajax({
        url: targetDomain+'/myAssistant_photo.php', // point to server-side controller method
        dataType: 'html', // what to expect back from the server
        cache: false,
        contentType: false,
        processData: false,
        data: form_data,
        type: 'post',
        success: function (data) {
            $.cookie('avatarpath',data);
            // display success response from the server

        },
        error: function (e) {
          console.log(e);// display error response from the server
        }
    });
    return true;
}

/*Loads photo from local system to input form
*/
function loadPhoto(fileSelector) {
	var files = fileSelector.files;
    // FileReader support
    if (FileReader && files && files.length) {
        var fr = new FileReader();
        fr.onload = function () {
            document.getElementById('avatar').src = fr.result;
        }
        fr.readAsDataURL(files[0]);
    }

    // Not supported
    else {
        // fallback -- perhaps submit the input to an iframe and temporarily store
        // them on the server until the user's session ends.
    }
}
